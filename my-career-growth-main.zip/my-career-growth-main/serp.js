import { getJson } from "serpapi";


    const response = await getJson({
        engine: "google_jobs",
        api_key: "9e0f76de52e28d1f0bcadb25c9f6e30702df15749970a4c6873835ffdff2a0f7", // Get your API_KEY from https://serpapi.com/manage-api-key
        q: "full stack developer",
        location: "",
    });
    console.log(response.jobs_results);

