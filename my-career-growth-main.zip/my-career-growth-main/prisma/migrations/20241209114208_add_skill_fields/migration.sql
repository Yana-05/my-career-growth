-- CreateTable
CREATE TABLE "resumes" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "title" TEXT,
    "description" TEXT,
    "photoUrl" TEXT,
    "colorHex" TEXT NOT NULL DEFAULT '#000000',
    "borderStyle" TEXT NOT NULL DEFAULT 'squircle',
    "summary" TEXT,
    "firstName" TEXT,
    "lastName" TEXT,
    "jobTitle" TEXT,
    "city" TEXT,
    "country" TEXT,
    "phone" TEXT,
    "email" TEXT,
    "skills" TEXT[],
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "resumes_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "work_experiences" (
    "id" TEXT NOT NULL,
    "position" TEXT,
    "company" TEXT,
    "startDate" TIMESTAMP(3),
    "endDate" TIMESTAMP(3),
    "description" TEXT,
    "resumeId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "work_experiences_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "educations" (
    "id" TEXT NOT NULL,
    "degree" TEXT,
    "school" TEXT,
    "startDate" TIMESTAMP(3),
    "endDate" TIMESTAMP(3),
    "resumeId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "educations_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "user_subscriptions" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "stripeCustomerId" TEXT NOT NULL,
    "stripeSubscriptionId" TEXT NOT NULL,
    "stripePriceId" TEXT NOT NULL,
    "stripeCurrentPeriodEnd" TIMESTAMP(3) NOT NULL,
    "stripeCancelAtPeriodEnd" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "user_subscriptions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "UpskillRoadmap" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "resumeId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "strengths" TEXT[],
    "weaknesses" TEXT[],
    "criticalDeficiencies" TEXT[],
    "currentRole" TEXT NOT NULL,
    "futureRoles" TEXT[],
    "transitionSteps" TEXT[],
    "emergingTrends" TEXT[],

    CONSTRAINT "UpskillRoadmap_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "IndustryStandardProficiency" (
    "id" TEXT NOT NULL,
    "skill" TEXT NOT NULL,
    "requiredProficiency" INTEGER NOT NULL,
    "roadmapId" TEXT NOT NULL,

    CONSTRAINT "IndustryStandardProficiency_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "LearningPhase" (
    "id" TEXT NOT NULL,
    "phaseTitle" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "conceptsToMaster" TEXT[],
    "technologiesToLearn" TEXT[],
    "roadmapId" TEXT NOT NULL,

    CONSTRAINT "LearningPhase_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "LearningIntervention" (
    "id" TEXT NOT NULL,
    "courseTitle" TEXT NOT NULL,
    "platform" TEXT NOT NULL,
    "link" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "roadmapId" TEXT NOT NULL,

    CONSTRAINT "LearningIntervention_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "TimelinePhase" (
    "id" TEXT NOT NULL,
    "phase" TEXT NOT NULL,
    "duration" TEXT NOT NULL,
    "milestones" TEXT[],
    "roadmapId" TEXT NOT NULL,

    CONSTRAINT "TimelinePhase_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "user_subscriptions_userId_key" ON "user_subscriptions"("userId");

-- CreateIndex
CREATE UNIQUE INDEX "user_subscriptions_stripeCustomerId_key" ON "user_subscriptions"("stripeCustomerId");

-- CreateIndex
CREATE UNIQUE INDEX "user_subscriptions_stripeSubscriptionId_key" ON "user_subscriptions"("stripeSubscriptionId");

-- CreateIndex
CREATE INDEX "UpskillRoadmap_userId_idx" ON "UpskillRoadmap"("userId");

-- CreateIndex
CREATE INDEX "UpskillRoadmap_resumeId_idx" ON "UpskillRoadmap"("resumeId");

-- CreateIndex
CREATE INDEX "IndustryStandardProficiency_roadmapId_idx" ON "IndustryStandardProficiency"("roadmapId");

-- CreateIndex
CREATE INDEX "LearningPhase_roadmapId_idx" ON "LearningPhase"("roadmapId");

-- CreateIndex
CREATE INDEX "LearningIntervention_roadmapId_idx" ON "LearningIntervention"("roadmapId");

-- CreateIndex
CREATE INDEX "TimelinePhase_roadmapId_idx" ON "TimelinePhase"("roadmapId");

-- AddForeignKey
ALTER TABLE "work_experiences" ADD CONSTRAINT "work_experiences_resumeId_fkey" FOREIGN KEY ("resumeId") REFERENCES "resumes"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "educations" ADD CONSTRAINT "educations_resumeId_fkey" FOREIGN KEY ("resumeId") REFERENCES "resumes"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UpskillRoadmap" ADD CONSTRAINT "UpskillRoadmap_resumeId_fkey" FOREIGN KEY ("resumeId") REFERENCES "resumes"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "IndustryStandardProficiency" ADD CONSTRAINT "IndustryStandardProficiency_roadmapId_fkey" FOREIGN KEY ("roadmapId") REFERENCES "UpskillRoadmap"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "LearningPhase" ADD CONSTRAINT "LearningPhase_roadmapId_fkey" FOREIGN KEY ("roadmapId") REFERENCES "UpskillRoadmap"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "LearningIntervention" ADD CONSTRAINT "LearningIntervention_roadmapId_fkey" FOREIGN KEY ("roadmapId") REFERENCES "UpskillRoadmap"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TimelinePhase" ADD CONSTRAINT "TimelinePhase_roadmapId_fkey" FOREIGN KEY ("roadmapId") REFERENCES "UpskillRoadmap"("id") ON DELETE CASCADE ON UPDATE CASCADE;
