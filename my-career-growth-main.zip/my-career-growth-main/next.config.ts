import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  experimental: {
    serverActions: {
      bodySizeLimit: "4mb",
    },
  },
  images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: "ixhic4gxqndlfbfy.public.blob.vercel-storage.com"
      }
    ]
  },
  webpack: (config, { isServer }) => {
    config.ignoreWarnings = [
      { module: /node_modules\/pdf-parse/ },
    ];
    return config;
  },
};

export default nextConfig;
