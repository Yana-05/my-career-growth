import { X, Copy, Check } from 'lucide-react';
import { useState } from 'react';

interface CoverLetterModalProps {
    isOpen: boolean;
    onClose: () => void;
    coverLetter: string;
}

export function CoverLetterModal({ isOpen, onClose, coverLetter }: CoverLetterModalProps) {
    const [copied, setCopied] = useState(false);

    const handleCopy = async () => {
        await navigator.clipboard.writeText(coverLetter);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-lg w-full max-w-3xl max-h-[80vh] overflow-hidden flex flex-col">
                <div className="p-4 border-b flex justify-between items-center">
                    <h2 className="text-xl font-semibold">Your Custom Cover Letter</h2>
                    <div className="flex gap-2">
                        <button
                            onClick={handleCopy}
                            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                            title="Copy to clipboard"
                        >
                            {copied ? <Check className="w-5 h-5 text-green-500" /> : <Copy className="w-5 h-5" />}
                        </button>
                        <button
                            onClick={onClose}
                            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                        >
                            <X className="w-5 h-5" />
                        </button>
                    </div>
                </div>
                <div className="p-6 overflow-y-auto flex-1">
                    <div className="whitespace-pre-wrap text-sm">{coverLetter}</div>
                </div>
            </div>
        </div>
    );
}
