import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function FeatureCard({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) {
    return (
        <Card className="bg-white border-gray-200 shadow-sm hover:shadow-md transition-shadow h-44 cursor-pointer">
            <CardHeader>
                <CardTitle className="flex items-center space-x-2 text-gray-900">
                    {icon}
                    <span>{title}</span>
                </CardTitle>
            </CardHeader>
            <CardContent>
                <CardDescription className="text-gray-600">{description}</CardDescription>
            </CardContent>
        </Card>
    )
}