import { Dialog, DialogContent, DialogHeader, DialogTitle } from "./ui/dialog";
import Image from "next/image";
import { useRouter } from "next/navigation";

interface Template {
  id: string;
  name: string;
  image: string;
  description: string;
}

const RESUME_TEMPLATES: Template[] = [
  {
    id: "classic",
    name: "Classic",
    image: "/ClassicTemplate.png",
    description: "Traditional and professional layout"
  },
  {
    id: "modern",
    name: "ATS-Friendly",
    image: "/ATS-Friendly.png",
    description: "Clean ATS Compliant Layout"
  },
  {
    id: "minimalist",
    name: "Minimalist",
    image: "/Minimalist.png",
    description: "Clean and modern layout"
  }

  // Add more templates as needed
];

interface TemplateSelectionModalProps {
  open: boolean;
  onClose: () => void;
}

export function TemplateSelectionModal({ open, onClose }: TemplateSelectionModalProps) {
  const router = useRouter();

  const handleTemplateSelect = async (templateId: string) => {
    const response = await fetch("/api/resumes", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ template: templateId }),
    });

    const { id } = await response.json();
    router.push(`/editor/?resumeId=${id}&template=${templateId}`);
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl p-20 overflow-y-scroll max-h-[90vh] ">
        <DialogHeader>
          <DialogTitle>Choose a Template</DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-1 gap-4 p-4 sm:grid-cols-2 md:grid-cols-3">
          {RESUME_TEMPLATES.map((template) => (
            <button
              key={template.id}
              onClick={() => handleTemplateSelect(template.id)}
              className="group relative  min-h-[400px] overflow-hidden rounded-lg border-purple-600 border-2 hover:border-primary hover:shadow-lg"
            >
              <Image
                src={template.image}
                alt={template.name}
                fill
                className="object-cover group-hover:scale-103"
              />
              <div className="absolute bottom-0 w-full gradient-primary p-2 text-white">
                <p className="font-medium">{template.name}</p>
                <p className="text-xs text-gray-200">{template.description}</p>
              </div>
            </button>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
} 