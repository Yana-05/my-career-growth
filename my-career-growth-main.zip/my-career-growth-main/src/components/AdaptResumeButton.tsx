// src/components/AdaptResumeButton.tsx
'use client'

import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Resume } from '@prisma/client';
import { WandSparklesIcon } from 'lucide-react';
import { JobInterface } from '@/lib/types';
import { useRouter } from 'next/navigation';
import Image from "next/image";

interface AdaptResumeButtonProps {
    selectedJob: JobInterface;
    selectedResume: Resume;
}

const RESUME_TEMPLATES = [
    {
        id: "classic",
        name: "Classic",
        image: "/ClassicTemplate.png",
        description: "Traditional and professional layout"
    },
    {
        id: "modern",
        name: "ATS-Friendly",
        image: "/ATS-Friendly.png",
        description: "Clean ATS Compliant Layout"
    },
    {
        id: "minimalist",
        name: "Minimalist",
        image: "/Minimalist.png",
        description: "Clean and modern layout"
    }
];

export function AdaptResumeButton({ selectedJob, selectedResume }: AdaptResumeButtonProps) {
    const [isOpen, setIsOpen] = useState(false);
    const [step, setStep] = useState<'select-resume' | 'select-template'>('select-resume');
    const [resumes, setResumes] = useState<Resume[]>([]);
    const [selectedResumeForAdapt, setSelectedResumeForAdapt] = useState<Resume | null>(null);
    const [loading, setLoading] = useState(false);
    const router = useRouter();

    const fetchResumes = async () => {
        try {
            const response = await fetch('/api/resumes');
            const data = await response.json();
            setResumes(data);
        } catch (error) {
            console.error('Error fetching resumes:', error);
        }
    };

    const handleOpen = async () => {
        setIsOpen(true);
        await fetchResumes();
    };

    const handleResumeSelect = (resume: Resume) => {
        setSelectedResumeForAdapt(resume);
        setStep('select-template');
    };

    const handleTemplateSelect = async (templateId: string) => {
        setLoading(true);
        try {
            const response = await fetch('/api/adapt-resume', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    resumeId: selectedResumeForAdapt?.id,
                    jobDescription: selectedJob.description,
                    templateId,
                }),
            });

            const data = await response.json();
            const url = `${window.location.origin}/editor?resumeId=${data.id}`;
            router.push(url);
        } catch (error) {
            console.error('Error adapting resume:', error);
        } finally {
            setLoading(false);
            setIsOpen(false);
        }
    };

    return (
        <>
            <button
                onClick={handleOpen}
                className="flex-1 px-6 py-3 gradient-primary border-2 border-purple-500 text-white rounded-lg hover:bg-purple-100/40 text-center flex items-center justify-center"
            >
                Adapt Resume <WandSparklesIcon className="w-4 h-4 ml-1" />
            </button>

            <Dialog open={isOpen} onOpenChange={() => setIsOpen(false)}>
                <DialogContent className="max-w-6xl p-20 overflow-y-scroll max-h-[90vh]">
                    <DialogHeader>
                        <DialogTitle>
                            {step === 'select-resume' ? 'Select Resume to Adapt' : 'Choose Template'}
                        </DialogTitle>
                    </DialogHeader>

                    {step === 'select-resume' ? (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {resumes.map((resume) => (
                                <button
                                    key={resume.id}
                                    onClick={() => handleResumeSelect(resume)}
                                    className="p-4 border rounded-lg text-left hover:border-purple-500"
                                >
                                    <h3 className="font-medium">{resume.title}</h3>
                                    <p className="text-sm text-gray-600">
                                        {new Date(resume.updatedAt).toLocaleDateString()}
                                    </p>
                                </button>
                            ))}
                        </div>
                    ) : (
                        <div className="grid grid-cols-1 gap-4 p-4 sm:grid-cols-2 md:grid-cols-3">
                            {loading ? (
                                <div className="col-span-full flex flex-col items-center justify-center p-12">
                                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-500 mb-4"></div>
                                    <p className="text-lg text-gray-700">Processing Adapted Resume...</p>
                                </div>
                            ) : (
                                RESUME_TEMPLATES.map((template) => (
                                    <button
                                        key={template.id}
                                        onClick={() => handleTemplateSelect(template.id)}
                                        className="group relative min-h-[400px] overflow-hidden rounded-lg border-purple-600 border-2 hover:border-primary hover:shadow-lg"
                                        disabled={loading}
                                    >
                                        <Image
                                            src={template.image}
                                            alt={template.name}
                                            fill
                                            className="object-cover group-hover:scale-103"
                                        />
                                        <div className="absolute bottom-0 w-full gradient-primary p-2 text-white">
                                            <p className="font-medium">{template.name}</p>
                                            <p className="text-xs text-gray-200">{template.description}</p>
                                        </div>
                                    </button>
                                ))
                            )}
                        </div>
                    )}
                </DialogContent>
            </Dialog>
        </>
    );
}