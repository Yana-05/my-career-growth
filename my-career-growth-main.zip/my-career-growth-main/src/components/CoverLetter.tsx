'use client'

import { useState } from 'react';
import { CoverLetterModal } from './CoverLetterModal';
import { JobInterface } from '@/lib/types';
import { Resume } from '@prisma/client';
import { Loader2, WandSparklesIcon } from 'lucide-react';

interface CoverLetterButtonProps {
    selectedJob: JobInterface;
    selectedResume: Resume;
}

export function CoverLetterButton({ selectedJob, selectedResume }: CoverLetterButtonProps) {
    const [isGenerating, setIsGenerating] = useState(false);
    const [coverLetter, setCoverLetter] = useState('');
    const [isModalOpen, setIsModalOpen] = useState(false);

    const generateCoverLetter = async () => {
        if (!selectedJob || !selectedResume) return;

        setIsGenerating(true);
        try {
            const response = await fetch('/api/cover-letter', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },

                body: JSON.stringify({
                    jobDescription: selectedJob.description,
                    jobTitle: selectedJob.title,
                    companyName: selectedJob.company_name,
                    resume: {
                        //@ts-ignore
                        workExperience: selectedResume.workExperiences,
                        skills: selectedResume.skills,
                        name: `${selectedResume.firstName} ${selectedResume.lastName}`,
                    }
                }),
            });

            const data = await response.json();
            setCoverLetter(data.coverLetter);
            setIsModalOpen(true);
        } catch (error) {
            console.error('Error generating cover letter:', error);
            // You might want to add toast notification here
        } finally {
            setIsGenerating(false);
        }
    };

    return (
        <>
            <button
                onClick={generateCoverLetter}
                disabled={isGenerating}
                className="flex-1 flex items-center text-center justify-center gap-2 px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:bg-indigo-300 disabled:cursor-not-allowed"
            >
                {isGenerating ? "" : <WandSparklesIcon className="size-4" />}
                {isGenerating ? 'Generating...' : 'Generate Cover Letter'}
                {isGenerating && <Loader2 className="size-4 animate-spin" />}
            </button>

            <CoverLetterModal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                coverLetter={coverLetter}
            />
        </>
    );
}
