import { ResumeTemplateProps } from ".";
import useDimensions from "@/hooks/useDimensions";
import { cn } from "@/lib/utils";
import { formatDate } from "date-fns";
import Image from "next/image";
import React, { useEffect, useRef, useState } from "react";

export default function ModernTemplate({
    resumeData,
    contentRef,
    className,
}: ResumeTemplateProps) {
    const containerRef = useRef<HTMLDivElement>(null);
    const { width } = useDimensions(containerRef);

    return (
        <div
            className={cn(
                "aspect-[210/297] h-fit w-full bg-white text-black",
                className
            )}
            ref={containerRef}
        >
            <div
                className={cn("p-8", !width && "invisible")}
                style={{
                    zoom: (1 / 794) * width,
                }}
                ref={contentRef}
                id="resumePreviewContent"
            >
                <Header resumeData={resumeData} />
                <Experience resumeData={resumeData} />
                <Education resumeData={resumeData} />
                <Other resumeData={resumeData} />
            </div>
        </div>
    );
}

function Header({ resumeData }: { resumeData: ResumeTemplateProps["resumeData"] }) {
    const { firstName, lastName, email, phone, city, country } = resumeData;

    return (
        <div className="mb-8 space-y-2">
            <h1 className="text-3xl font-bold">
                {firstName} {lastName}
            </h1>
            <p className="text-sm text-gray-600">
                {[email, phone, city, country].filter(Boolean).join(" | ")}
            </p>
        </div>
    );
}

function Experience({ resumeData }: { resumeData: ResumeTemplateProps["resumeData"] }) {
    const { workExperiences } = resumeData;

    if (!workExperiences?.length) return null;

    return (
        <section className="mb-6">
            <h2 className="mb-4 border-b border-black text-lg font-bold uppercase">EXPERIENCE</h2>
            <div className="space-y-4">
                {workExperiences.map((exp, index) => (
                    <div key={index} className="break-inside-avoid">
                        <div className="flex justify-between">
                            <div>
                                <h3 className="font-bold">{exp.company}</h3>
                                <p className="text-sm italic">{exp.position}</p>
                            </div>
                            {exp.startDate && (
                                <p className="text-sm">
                                    {formatDate(exp.startDate, "MMM yyyy")} –{" "}
                                    {exp.endDate ? formatDate(exp.endDate, "MMM yyyy") : "Present"}
                                </p>
                            )}
                        </div>
                        <p className="mt-2 whitespace-pre-line text-sm">{exp.description}</p>
                    </div>
                ))}
            </div>
        </section>
    );
}

function Education({ resumeData }: { resumeData: ResumeTemplateProps["resumeData"] }) {
    const { educations } = resumeData;

    if (!educations?.length) return null;

    return (
        <section className="mb-6">
            <h2 className="mb-4 border-b border-black text-lg font-bold uppercase">EDUCATION</h2>
            <div className="space-y-4">
                {educations.map((edu, index) => (
                    <div key={index} className="break-inside-avoid">
                        <div className="flex justify-between">
                            <div>
                                <h3 className="font-bold">{edu.school}</h3>
                                <p className="text-sm">{edu.degree}</p>
                            </div>
                            {edu.startDate && (
                                <p className="text-sm">
                                    {formatDate(edu.startDate, "MMM yyyy")}
                                    {edu.endDate && ` – ${formatDate(edu.endDate, "MMM yyyy")}`}
                                </p>
                            )}
                        </div>
                    </div>
                ))}
            </div>
        </section>
    );
}

function Other({ resumeData }: { resumeData: ResumeTemplateProps["resumeData"] }) {
    const { skills } = resumeData;

    if (!skills?.length) return null;

    return (
        <section>
            <h2 className="mb-4 border-b border-black text-lg font-bold uppercase">OTHER</h2>
            <div className="space-y-2">
                <div>
                    <span className="font-bold">Technical Skills:</span>{" "}
                    <span className="text-sm">{skills.join(", ")}</span>
                </div>
            </div>
        </section>
    );
}