import { ResumeValues } from "@/lib/validation";
import ClassicTemplate from "./ClassicTemplate";
import ModernTemplate from "./ModernTemplate";
import MinimalistTemplate from "./MinimalistTemplate";

export interface ResumeTemplateProps {
    resumeData: ResumeValues;
    contentRef?: React.Ref<HTMLDivElement>;
    className?: string;
}

export const RESUME_TEMPLATES: Record<string, React.ComponentType<ResumeTemplateProps>> = {
    classic: ClassicTemplate,
    modern: ModernTemplate,
    minimalist: MinimalistTemplate,
};

export type TemplateId = keyof typeof RESUME_TEMPLATES; 