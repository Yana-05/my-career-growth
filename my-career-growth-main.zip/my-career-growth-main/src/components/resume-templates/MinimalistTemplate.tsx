import { ResumeTemplateProps } from ".";
import useDimensions from "@/hooks/useDimensions";
import { cn } from "@/lib/utils";
import { formatDate } from "date-fns";
import React, { useRef } from "react";

export default function MinimalistTemplate({
    resumeData,
    contentRef,
    className,
}: ResumeTemplateProps) {
    const containerRef = useRef<HTMLDivElement>(null);
    const { width } = useDimensions(containerRef);

    return (
        <div
            className={cn(
                "aspect-[210/297] h-fit w-full bg-white text-black",
                className
            )}
            ref={containerRef}
        >
            <div
                className={cn("p-8", !width && "invisible")}
                style={{
                    zoom: (1 / 794) * width,
                }}
                ref={contentRef}
                id="resumePreviewContent"
            >
                <Header resumeData={resumeData} />
                <Summary resumeData={resumeData} />
                <Experience resumeData={resumeData} />
                <Education resumeData={resumeData} />
                <Skills resumeData={resumeData} />
            </div>
        </div>
    );
}

function Header({ resumeData }: { resumeData: ResumeTemplateProps["resumeData"] }) {
    const { firstName, lastName, email, phone, city, country } = resumeData;

    return (
        <div className="mb-6 text-center">
            <h1 className="mb-2 text-3xl font-bold">{`${firstName} ${lastName}`}</h1>
            <p className="text-sm text-gray-600">
                {[city, country].filter(Boolean).join(", ")} • {email} • {phone}
            </p>
        </div>
    );
}

function Summary({ resumeData }: { resumeData: ResumeTemplateProps["resumeData"] }) {
    if (!resumeData.summary) return null;

    return (
        <section className="mb-6">
            <h2 className="mb-2 border-b border-gray-300 pb-1 text-lg font-bold uppercase">
                Professional Summary
            </h2>
            <p className="text-sm">{resumeData.summary}</p>
        </section>
    );
}

function Experience({ resumeData }: { resumeData: ResumeTemplateProps["resumeData"] }) {
    if (!resumeData.workExperiences?.length) return null;

    return (
        <section className="mb-6">
            <h2 className="mb-2 border-b border-gray-300 pb-1 text-lg font-bold uppercase">
                Professional Experience
            </h2>
            <div className="space-y-4">
                {resumeData.workExperiences.map((exp, index) => (
                    <div key={index} className="break-inside-avoid">
                        <div className="flex justify-between">
                            <div>
                                <h3 className="font-bold">{exp.position}</h3>
                                <p className="text-sm">{exp.company}</p>
                            </div>
                            {exp.startDate && (
                                <p className="text-sm text-gray-600">
                                    {formatDate(exp.startDate, "MMMM yyyy")}—
                                    {exp.endDate ? formatDate(exp.endDate, "MMMM yyyy") : "Present"}
                                    {/* {exp.city && `, ${exp.city}`} */}
                                </p>
                            )}
                        </div>
                        <ul className="mt-2 list-disc space-y-1 pl-4 text-sm">
                            {exp.description?.split('\n').map((bullet, i) => (
                                <li key={i}>{bullet}</li>
                            ))}
                        </ul>
                    </div>
                ))}
            </div>
        </section>
    );
}

function Education({ resumeData }: { resumeData: ResumeTemplateProps["resumeData"] }) {
    if (!resumeData.educations?.length) return null;

    return (
        <section className="mb-6">
            <h2 className="mb-2 border-b border-gray-300 pb-1 text-lg font-bold uppercase">
                Education
            </h2>
            {resumeData.educations.map((edu, index) => (
                <div key={index} className="mb-2 break-inside-avoid">
                    <div className="flex justify-between">
                        <div>
                            <h3 className="font-bold">{edu.degree}</h3>
                            <p className="text-sm">{edu.school}</p>
                        </div>
                        {edu.startDate && (
                            <p className="text-sm text-gray-600">
                                {formatDate(edu.startDate, "yyyy")}
                                {edu.endDate && ` - ${formatDate(edu.endDate, "yyyy")}`}
                            </p>
                        )}
                    </div>
                </div>
            ))}
        </section>
    );
}

function Skills({ resumeData }: { resumeData: ResumeTemplateProps["resumeData"] }) {
    if (!resumeData.skills?.length) return null;

    return (
        <section>
            <h2 className="mb-2 border-b border-gray-300 pb-1 text-lg font-bold uppercase">
                Expert-Level Skills
            </h2>
            <div className="text-sm">
                {resumeData.skills.map((skill, index, array) => (
                    <React.Fragment key={index}>
                        {skill}
                        {index < array.length - 1 && ", "}
                    </React.Fragment>
                ))}
            </div>
        </section>
    );
}
