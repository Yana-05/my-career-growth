"use client"

import { PolarAngleAxis, PolarGrid, Radar, RadarChart } from "recharts"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import {
  ChartConfig,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart"

interface SkillProficiency {
  skill: string
  proficiency: number
}

interface IndustryStandard {
  skill: string
  requiredProficiency: number
}

interface SkillRadarChartProps {
  userSkills: SkillProficiency[]
  industryStandards: IndustryStandard[]
}

const chartConfig = {
  userProficiency: {
    label: "Your Proficiency",
    color: "hsl(var(--chart-1))",
  },
  industryStandard: {
    label: "Industry Standard",
    color: "hsl(var(--chart-2))",
  },
} satisfies ChartConfig

export function SkillRadarChart({ userSkills, industryStandards }: SkillRadarChartProps) {
  // Transform data for the radar chart
  const chartData = industryStandards.map(standard => {
    const userSkill = userSkills.find(
      skill => skill.skill.toLowerCase() === standard.skill.toLowerCase()
    )

    return {
      skill: standard.skill,
      userProficiency: userSkill?.proficiency || 0,
      industryStandard: standard.requiredProficiency,
    }
  })

  return (
    <Card className="mx-4">
      <CardHeader className="items-center pb-4">
        <CardTitle>Skill Proficiency Analysis</CardTitle>
        <CardDescription>
          Your skills vs. Industry standards
        </CardDescription>
      </CardHeader>
      <CardContent className="pb-4">
        <ChartContainer
          config={chartConfig}
          className="mx-auto aspect-square max-h-[350px] px-4"

        >
          <RadarChart
            data={chartData}
            margin={{
              top: 10,
              right: 10,
              bottom: 10,
              left: 10,
            }}

          >
            <ChartTooltip
              cursor={false}
              content={<ChartTooltipContent indicator="line" />}
            />
            <PolarAngleAxis
              dataKey="skill"
              tick={({ x, y, textAnchor, value, index, ...props }) => {
                const data = chartData[index]
                return (
                  <text
                    x={x}
                    y={index === 0 ? y - 10 : y}
                    textAnchor={textAnchor}
                    fontSize={13}
                    fontWeight={500}
                    {...props}
                  >
                    <tspan>{data.userProficiency}%</tspan>
                    <tspan className="fill-muted-foreground">/</tspan>
                    <tspan>{data.industryStandard}%</tspan>
                    <tspan
                      x={x}
                      dy={"1rem"}
                      fontSize={12}
                      className="fill-muted-foreground"
                    >
                      {data.skill}
                    </tspan>
                  </text>
                )
              }}
            />
            <PolarGrid />
            <Radar
              dataKey="userProficiency"
              fill="var(--color-userProficiency)"
              fillOpacity={0.6}
            />
            <Radar
              dataKey="industryStandard"
              fill="var(--color-industryStandard)"
              fillOpacity={0.4}
            />
          </RadarChart>
        </ChartContainer>
      </CardContent>
    </Card>
  )
}
