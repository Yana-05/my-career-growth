declare module 'pdf-parse' {
    function PDFParser(dataBuffer: Uint8Array): Promise<{ text: string }>;
    export default PDFParser;
} 