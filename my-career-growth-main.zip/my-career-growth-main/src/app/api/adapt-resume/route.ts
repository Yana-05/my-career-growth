import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import openai from "@/lib/openai"
import { createClient } from "@/utils/supabase/server";



export async function POST(req: Request) {
    try {
        const supabase = await createClient();
        const { data, error } = await supabase.auth.getUser();
        if (!data.user) {
            return new NextResponse("Unauthorized", { status: 401 });
        }

        const { resumeId, jobDescription, templateId } = await req.json();

        // Fetch the original resume
        const originalResume = await prisma.resume.findUnique({
            where: { id: resumeId },
            include: {
                workExperiences: true,
                educations: true,
            },
        });

        if (!originalResume) {
            return new NextResponse("Resume not found", { status: 404 });
        }

        // Use OpenAI to adapt the resume content
        const completion = await openai.chat.completions.create({
            model: "gpt-4",
            messages: [
                {
                    role: "system",
                    content: `You are an expert resume writer. Your task is to adapt only the description of each work experience to better match the job description while maintaining truthfulness.
                    Return the work experiences array with the same structure but with optimized descriptions.
                    
                    Format the descriptions with:
                    - Line breaks (\\n) between points
                    - 3-5 bullet points per role
                    - Quantifiable achievements where possible
                    
                    Keep all other fields (position, company, dates) exactly the same as provided.`,
                },
                {
                    role: "user",
                    content: `Job Description: ${jobDescription}\n\nCurrent Work Experiences: ${JSON.stringify(
                        originalResume.workExperiences
                    )}\n\nPlease optimize only the descriptions while keeping all other fields unchanged.`,
                },
            ],
        });

        // Then use the original work experience data but update only the descriptions
        const adaptedContent = originalResume.workExperiences.map((exp, index) => ({
            ...exp,
            description: JSON.parse(completion.choices[0].message.content || "[]")[index]?.description || exp.description
        }));

        // Create new resume with adapted content
        const newResume = await prisma.resume.create({
            data: {
                ...originalResume,
                id: undefined,
                createdAt: undefined,
                updatedAt: undefined,
                title: `${originalResume.title} (Adapted)`,
                template: templateId,
                skills: originalResume.skills,
                workExperiences: {
                    create: adaptedContent.map((exp: any) => ({
                        position: exp.position,
                        company: exp.company,
                        startDate: new Date(exp.startDate),
                        endDate: exp.endDate ? new Date(exp.endDate) : null,
                        description: exp.description
                    }))
                },
                educations: {
                    create: originalResume.educations.map((edu: any) => ({
                        school: edu.school,
                        degree: edu.degree,
                        startDate: edu.startDate,
                        endDate: edu.endDate
                    }))
                }
            },
            include: {
                workExperiences: true,
                educations: true
            }
        });
        console.log(adaptedContent)
        return NextResponse.json(newResume);
    } catch (error) {
        console.error("Error adapting resume:", error);
        return new NextResponse("Internal Server Error", { status: 500 });
    }
}
