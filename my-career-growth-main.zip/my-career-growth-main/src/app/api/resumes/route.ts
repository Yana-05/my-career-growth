import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { createClient } from "@/utils/supabase/server";

export async function GET() {
    try {
        const supabase = await createClient();
        const { data, error } = await supabase.auth.getUser();
        if (!data.user) {
            return new NextResponse("Unauthorized", { status: 401 });
        }

        const resumes = await prisma.resume.findMany({
            where: { userId: data.user.id },
            orderBy: { updatedAt: 'desc' }
        });

        return NextResponse.json(resumes);
    } catch (error) {
        console.error(error);
        return new NextResponse("Internal Error", { status: 500 });
    }
}

export async function POST(req: Request) {
    try {
        const supabase = await createClient();
        const { data, error } = await supabase.auth.getUser();

        if (!data.user) {
            return new NextResponse("Unauthorized", { status: 401 });
        }

        const { template } = await req.json();

        const resume = await prisma.resume.create({
            data: {
                userId: data.user.id,
                template,
            },
        });

        return NextResponse.json(resume);
    } catch (error) {
        console.error(error);
        return new NextResponse("Internal Error", { status: 500 });
    }
} 