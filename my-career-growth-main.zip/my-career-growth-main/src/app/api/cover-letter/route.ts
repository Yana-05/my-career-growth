import openai from '@/lib/openai';
import { NextResponse } from 'next/server';


export async function POST(req: Request) {
    try {
        const { jobDescription, jobTitle, companyName, resume } = await req.json();

        const systemMessage = `You are a strategic career communications expert specializing in crafting personalized, high-impact cover letters that:
                            - Precisely map candidate experiences to job requirements
                            - Demonstrate clear value proposition
                            - Showcase professional achievements
                            - Articulate unique professional narrative
                            - Align candidate's background with company's specific needs
                            - Use sophisticated, industry-appropriate language
                            - Balance professional tone with engaging storytelling

                            Key Objectives:
                            1. Highlight most relevant experiences
                            2. Demonstrate deep understanding of role
                            3. Provide concrete evidence of capabilities
                            4. Create a compelling professional narrative
                            5. Differentiate candidate from other applicants

                            Guiding Principles:
                            - Use quantifiable achievements
                            - Emphasize direct alignment with job description
                            - Show depth of technical and soft skills
                            - Maintain concise, impactful writing
                            - Adapt tone to industry and company culture`;


        const prompt = `Generate a professional cover letter for a ${jobTitle} position at ${companyName}. 
        
                        Job Description:
                        ${jobDescription}

                        My Work Experience:
                        ${resume.workExperience.map((exp: any) =>
            `- ${exp.position} at ${exp.company}: ${exp.description}`
        ).join('\n')}

                        My Skills:
                        ${resume.skills.join(', ')}

                        Specific Requirements for Crafting the Cover Letter:
                        1. Analyze job description to identify:
                        - Key technical requirements
                        - Critical soft skills
                        - Core responsibilities
                        - Company's implied cultural values

                        2. Match Experiences:
                        - Select 2-3 most relevant work experiences
                        - Highlight achievements that directly address job requirements
                        - Use specific examples with quantifiable outcomes

                        3. Skills Alignment:
                        - Explicitly connect skills to job requirements
                        - Demonstrate proficiency through concrete examples
                        - Show how skills solve potential challenges for the employer

                        4. Company Research Integration:
                        - Subtly reference company's mission or recent achievements
                        - Show genuine interest and research
                        - Explain why this specific role and company align with career goals

                        5. Structural Guidelines:
                        - Opening: Strong, attention-grabbing introduction
                        - Body: 2-3 paragraphs of targeted experience
                        - Closing: Confident call to action
                        - Total length: 300-400 words
                        - Tone: Professional, confident, enthusiastic

                        6. Additional Considerations:
                        - Address any potential gaps or transitions in experience
                        - Use industry-specific terminology
                        - Avoid generic statements
                        - Personalize content to feel authentic

                        Preferred Tone: Professional with a warm, confident undertone
                        Desired Outcome: Create a compelling narrative that positions the candidate as an ideal, unique fit for the role`;

        const completion = await openai.chat.completions.create({
            model: "gpt-4",
            messages: [
                {
                    "role": "system",
                    "content": systemMessage
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
        });

        return NextResponse.json({
            coverLetter: completion.choices[0].message.content
        });

    } catch (error) {
        console.error('Error:', error);
        return NextResponse.json(
            { error: 'Failed to generate cover letter' },
            { status: 500 }
        );
    }
}
