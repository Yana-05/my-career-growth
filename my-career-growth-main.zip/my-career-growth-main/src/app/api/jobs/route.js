import { NextResponse } from 'next/server';
import { getJson } from 'serpapi';

export async function GET(request) {
    try {
        const { searchParams } = new URL(request.url);
        const roles = searchParams.get('roles') || "full stack * OR nextjs OR reactjs OR typescript";
        const location = searchParams.get('location') || "india";

        const response = await getJson({
            engine: "google_jobs",
            api_key: process.env.SERP_API_KEY,
            q: roles,
            location: location,
        });
        return NextResponse.json(response.jobs_results);
    } catch (error) {
        return NextResponse.json({ error: 'Failed to fetch jobs' }, { status: 500 });
    }
}