import { Toaster } from "@/components/ui/toaster";
import type { Metadata } from "next";
import { ThemeProvider } from "next-themes";
import { Inter } from "next/font/google";
import "./globals.css";
import Navbar from "./(main)/Navbar";

import { cn } from "@/lib/utils";
import { AuthProvider } from "@/context/AuthContext";
import { createClient } from '@supabase/supabase-js';


const inter = Inter({ subsets: ["latin"] });

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!);

export const metadata: Metadata = {
  title: {
    template: "%s - MyCareerGrowth",
    absolute: "MyCareerGrowth",
  },
  description:
    "MyCareerGrowth is the easiest way to create a professional resume that will help you land your dream job.",
};

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const { data: { user } } = await supabase.auth.getUser();
  const userId = user?.id;
  return (
    //@ts-ignore
    <AuthProvider>
      <html lang="en" suppressHydrationWarning>
        <body className={cn(inter.className, "min-h-screen flex flex-col")}>

          <ThemeProvider
            attribute="class"
            defaultTheme="system"
            enableSystem
            disableTransitionOnChange
          >
            <Navbar />
            {children}
            <Toaster />
          </ThemeProvider>
        </body>
      </html>
    </AuthProvider>
  );
}
