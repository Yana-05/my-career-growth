'use client'

import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription, } from '@/components/ui/card'
import { Loader2, WandSparklesIcon } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import { Resume } from '@prisma/client'
import { generateRoadmap, getLatestRoadmap } from './actions'
import LoadingButton from '@/components/LoadingButton'
import usePremiumModal from '@/hooks/usePremiumModal'
import { useSubscriptionLevel } from '../SubscriptionLevelProvider'
import { canUseAITools } from '@/lib/permissions'
import { motion } from 'framer-motion'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Briefcase, TrendingUp, BookOpen, Target, Clock, Award } from 'lucide-react'
import RoadmapCard from '@/components/RoadmapCard'
import SkillProficiencySlider from "@/components/SkillProficiencySlider"
import { SkillRadarChart } from '@/components/skillRadarChart'
import { AIResponse } from '@/lib/types'
import { useRouter } from 'next/navigation'


interface Props {
    initialResumes: Resume[]
}

interface RoadmapData {
    skillGapAnalysis: {
        strengths: string[];
        weaknesses: string[];
        criticalDeficiencies: string[];
        industryStandardProficiencies: {
            skill: string;
            requiredProficiency: number;
        }[];
    };
    strategicLearningPath: {
        phases: {
            phaseTitle: string;
            description: string;
            conceptsToMaster: string[];
            technologiesToLearn: string[];
        }[];
    };
    learningInterventions: {
        courseTitle: string;
        platform: string;
        link: string;
        description: string;
    }[];
    tacticalTimeline: {
        phase: string;
        duration: string;
        milestones: string[];
    }[];
    careerProgression: {
        currentRole: string;
        futureRoles: string[];
        transitionSteps: string[];
    };
    emergingTrends: string[];
}

interface SkillProficiency {
    skill: string;
    proficiency: number;
}

export default function ClientUpskillRoadmap({ initialResumes }: Props) {
    const [selectedResume, setSelectedResume] = useState<Resume | null>(null)
    const [roadmap, setRoadmap] = useState<string>('')
    const [loading, setLoading] = useState(false)
    const { toast } = useToast()
    const subscriptionLevel = useSubscriptionLevel()
    const premiumModal = usePremiumModal()
    const router = useRouter()

    const [inputType, setInputType] = useState<'resume' | 'linkedin'>('resume')
    const [linkedinUrl, setLinkedinUrl] = useState('')
    const [isLoading, setIsLoading] = useState(false)
    const [roadmapData, setRoadmapData] = useState<RoadmapData | null>(null);
    const [skillProficiencies, setSkillProficiencies] = useState<SkillProficiency[]>([]);

    useEffect(() => {
        if (selectedResume?.skills) {
            setSkillProficiencies(
                selectedResume.skills.map(skill => ({
                    skill,
                    proficiency: 50 // Default to 50%
                }))
            );
        }
    }, [selectedResume]);

    const handleProficiencyChange = (skill: string, newValue: number) => {
        setSkillProficiencies(prev =>
            prev.map(sp =>
                sp.skill === skill ? { ...sp, proficiency: newValue } : sp
            )
        );
    };



    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault()
        setIsLoading(true)

        await new Promise(resolve => setTimeout(resolve, 2000))
        setRoadmapData({
            skillGapAnalysis: {
                strengths: [],
                weaknesses: [],
                criticalDeficiencies: [],
                industryStandardProficiencies: []
            },
            strategicLearningPath: {
                phases: []
            },
            learningInterventions: [],
            tacticalTimeline: [],
            careerProgression: {
                currentRole: "",
                futureRoles: [],
                transitionSteps: []
            },
            emergingTrends: []
        })
        setIsLoading(false)
    }

    const handleGenerateRoadmap = async () => {
        if (!selectedResume) return

        if (!canUseAITools(subscriptionLevel)) {
            // premiumModal.onOpen()
            return
        }

        try {
            setLoading(true)
            const data = await generateRoadmap(selectedResume, skillProficiencies)
            setRoadmapData({
                skillGapAnalysis: {
                    strengths: data.strengths,
                    weaknesses: data.weaknesses,
                    criticalDeficiencies: data.criticalDeficiencies,
                    industryStandardProficiencies: data.industryStandardProficiencies
                },
                strategicLearningPath: {
                    phases: data.strategicLearningPath
                },
                learningInterventions: data.learningInterventions,
                tacticalTimeline: data.tacticalTimeline,
                careerProgression: {
                    currentRole: data.currentRole,
                    futureRoles: data.futureRoles,
                    transitionSteps: data.transitionSteps
                },
                emergingTrends: data.emergingTrends
            })
        } catch (error) {
            toast({
                title: 'Error',
                description: 'Failed to generate roadmap. Please try again.',
                variant: 'destructive',
            })
        } finally {
            setLoading(false)
        }
    }

    useEffect(() => {
        const fetchExistingRoadmap = async () => {
            if (!selectedResume) return;

            try {
                const existingRoadmap = await getLatestRoadmap(selectedResume.id);

                if (existingRoadmap) {
                    // Transform the Prisma roadmap data to match RoadmapData structure
                    const transformedRoadmap: RoadmapData = {
                        skillGapAnalysis: {
                            strengths: existingRoadmap.strengths,
                            weaknesses: existingRoadmap.weaknesses,
                            criticalDeficiencies: existingRoadmap.criticalDeficiencies,
                            industryStandardProficiencies: existingRoadmap.industryStandardProficiencies.map(prof => ({
                                skill: prof.skill,
                                requiredProficiency: prof.requiredProficiency
                            }))
                        },
                        strategicLearningPath: {
                            phases: existingRoadmap.strategicLearningPath.map(phase => ({
                                phaseTitle: phase.phaseTitle,
                                description: phase.description,
                                conceptsToMaster: phase.conceptsToMaster,
                                technologiesToLearn: phase.technologiesToLearn
                            }))
                        },
                        learningInterventions: existingRoadmap.learningInterventions.map(intervention => ({
                            courseTitle: intervention.courseTitle,
                            platform: intervention.platform,
                            link: intervention.link,
                            description: intervention.description
                        })),
                        tacticalTimeline: existingRoadmap.tacticalTimeline.map(timeline => ({
                            phase: timeline.phase,
                            duration: timeline.duration,
                            milestones: timeline.milestones
                        })),
                        emergingTrends: existingRoadmap.emergingTrends,
                        careerProgression: {
                            currentRole: existingRoadmap.currentRole,
                            futureRoles: existingRoadmap.futureRoles,
                            transitionSteps: existingRoadmap.transitionSteps
                        }
                    };

                    setRoadmapData(transformedRoadmap);
                } else {
                    // Clear existing roadmap data if none exists for this resume
                    setRoadmapData(null);
                }
            } catch (error) {
                console.error('Error fetching existing roadmap:', error);
                toast({
                    title: 'Error',
                    description: 'Failed to fetch existing roadmap data.',
                    variant: 'destructive',
                });
            }
        };

        fetchExistingRoadmap();
    }, [selectedResume, toast]);

    return (
        <>
            <div className="min-h-screen bg-gradient-to-br from-gray-50 via-gray-50 to-white text-gray-800 py-12 px-4 sm:px-6 lg:px-8">
                <motion.div
                    className="max-w-7xl mx-auto"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                >
                    <div className="flex justify-end mb-4">
                        <Button
                            onClick={() => router.push('/progress-journey')}
                            className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white"
                        >
                            Begin Journey &gt;
                        </Button>
                    </div>

                    <div className="flex flex-col lg:flex-row gap-8">
                        <Card className="lg:w-1/3 lg:sticky lg:top-8 lg:self-start">
                            <CardHeader>
                                <CardTitle>Generate Your Roadmap</CardTitle>
                                <CardDescription>Choose your input method and let AI create your personalized upskill strategy</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <form onSubmit={handleSubmit} className="space-y-4">
                                    <Tabs defaultValue="resume" onValueChange={(value) => setInputType(value as 'resume' | 'linkedin')}>
                                        <TabsList className="grid w-full grid-cols-2">
                                            <TabsTrigger value="resume">Use Resume</TabsTrigger>
                                            <TabsTrigger value="linkedin">Use LinkedIn</TabsTrigger>
                                        </TabsList>
                                        <TabsContent value="resume">
                                            <Card className="mb-6">
                                                <CardContent className="pt-6">
                                                    <div className="space-y-4">
                                                        <div>
                                                            <label className="text-sm font-medium mb-2 block">Select Resume</label>
                                                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                                                                {initialResumes?.map((resume) => (
                                                                    <div
                                                                        key={resume.id}
                                                                        className={`p-4 border rounded-lg cursor-pointer transition-colors ${selectedResume?.id === resume.id
                                                                            ? 'border-primary bg-primary/10'
                                                                            : 'border-border hover:border-primary'
                                                                            }`}
                                                                        onClick={() => setSelectedResume(resume)}
                                                                    >
                                                                        <h3 className="text-sm">{resume.title}</h3>
                                                                        <p className="text-xs text-muted-foreground">
                                                                            Last updated: {new Date(resume.updatedAt).toLocaleDateString()}
                                                                        </p>
                                                                    </div>
                                                                ))}
                                                            </div>
                                                        </div>

                                                        {/* <LoadingButton
                                                            variant="outline"
                                                            onClick={handleGenerateRoadmap}
                                                            loading={loading}
                                                            disabled={!selectedResume}
                                                        >
                                                            <WandSparklesIcon className="size-4 mr-2" />
                                                            Generate Roadmap
                                                        </LoadingButton> */}

                                                        {roadmap && (
                                                            <Card>
                                                                <CardContent className="pt-6">
                                                                    <h2 className="text-xl font-semibold mb-4">Your Personalized Roadmap</h2>
                                                                    <div className="prose max-w-none whitespace-pre-wrap">
                                                                        {roadmap}
                                                                    </div>
                                                                </CardContent>
                                                            </Card>
                                                        )}
                                                    </div>
                                                </CardContent>
                                            </Card>
                                        </TabsContent>
                                        <TabsContent value="linkedin">
                                            <Input
                                                type="url"
                                                placeholder="Enter your LinkedIn profile URL"
                                                value={linkedinUrl}
                                                onChange={(e) => setLinkedinUrl(e.target.value)}
                                                className="w-full"
                                            />
                                        </TabsContent>
                                    </Tabs>
                                    {/* <Button type="submit" className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white" disabled={isLoading}>
                                        {isLoading ? 'Generating Roadmap...' : 'Generate Roadmap'}
                                    </Button> */}
                                    {selectedResume && skillProficiencies.length > 0 && (
                                        <Card className="mt-4">
                                            <CardHeader>
                                                <CardTitle>Skill Proficiency Assessment</CardTitle>
                                                <CardDescription>
                                                    Rate your current proficiency level for each skill
                                                </CardDescription>
                                            </CardHeader>
                                            <CardContent className="space-y-4">
                                                {skillProficiencies.map(({ skill, proficiency }) => (
                                                    <SkillProficiencySlider
                                                        key={skill}
                                                        skill={skill}
                                                        value={proficiency}
                                                        onChange={(newValue) =>
                                                            handleProficiencyChange(skill, newValue)
                                                        }
                                                    />
                                                ))}
                                            </CardContent>
                                        </Card>
                                    )}
                                    <LoadingButton
                                        variant="outline"
                                        onClick={handleGenerateRoadmap}
                                        // onClick={async () => {
                                        //     setLoading(true);
                                        //     await new Promise(resolve => setTimeout(resolve, 5000));
                                        //     console.log("nice");
                                        //     setLoading(false);
                                        // }}
                                        loading={loading}
                                        disabled={!selectedResume}
                                        className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white hover:text-white"
                                    >
                                        <WandSparklesIcon className="size-4 mr-2" />

                                        Generate Roadmap
                                    </LoadingButton>
                                    {loading && (
                                        <div className="text-center mt-2">
                                            <span className="text-indigo-500 text-xs">This may take a minute...</span>
                                        </div>
                                    )}
                                </form>
                            </CardContent>
                        </Card>

                        {roadmapData ? (
                            <motion.div
                                className="lg:w-2/3 grid grid-cols-1 md:grid-cols-2 gap-6"
                                initial={{ opacity: 0 }}
                                animate={{ opacity: 1 }}
                                transition={{ duration: 0.3, delay: 0.2 }}
                            >
                                <RoadmapCard
                                    icon={<TrendingUp className="h-6 w-6 text-indigo-600" />}
                                    title="Industry Standard Comparison"
                                    content={
                                        <SkillRadarChart
                                            userSkills={skillProficiencies}
                                            industryStandards={roadmapData.skillGapAnalysis.industryStandardProficiencies}
                                        />
                                    }
                                />
                                <RoadmapCard
                                    icon={<TrendingUp className="h-6 w-6 text-indigo-600" />}
                                    title="Skill Gap Analysis"
                                    content={
                                        <div className="space-y-4">
                                            <div>
                                                <h4 className="font-semibold">Strengths:</h4>
                                                <ul className="list-disc pl-5">
                                                    {roadmapData.skillGapAnalysis.strengths.map((skill, i) => (
                                                        <li key={i}>{skill}</li>
                                                    ))}
                                                </ul>
                                            </div>
                                            <div>
                                                <h4 className="font-semibold">Areas for Improvement:</h4>
                                                <ul className="list-disc pl-5">
                                                    {roadmapData.skillGapAnalysis.weaknesses.map((skill, i) => (
                                                        <li key={i}>{skill}</li>
                                                    ))}
                                                </ul>
                                            </div>
                                        </div>
                                    }
                                />
                                <RoadmapCard
                                    icon={<Briefcase className="h-6 w-6 text-purple-600" />}
                                    title="Strategic Learning Path"
                                    content={
                                        <div className="space-y-4">
                                            {roadmapData.strategicLearningPath.phases.map((phase, i) => (
                                                <div key={i}>
                                                    <h4 className="font-semibold">{phase.phaseTitle}</h4>
                                                    <p className="text-sm">{phase.description}</p>
                                                    <div className="mt-2">
                                                        <span className="text-xs font-semibold">Technologies: </span>
                                                        <span className="text-xs">{phase.technologiesToLearn.join(', ')}</span>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    }
                                />
                                <RoadmapCard
                                    icon={<BookOpen className="h-6 w-6 text-indigo-600" />}
                                    title="Recommended Courses"
                                    content={
                                        <div className="space-y-4">
                                            {roadmapData.learningInterventions.map((course, i) => (
                                                <div key={i} className="border-b pb-2 last:border-b-0">
                                                    <h4 className="font-semibold">{course.courseTitle}</h4>
                                                    <p className="text-sm">{course.description}</p>
                                                    <a
                                                        href={course.link}
                                                        target="_blank"
                                                        rel="noopener noreferrer"
                                                        className="text-xs text-indigo-600 hover:underline"
                                                    >
                                                        View on {course.platform}
                                                    </a>
                                                </div>
                                            ))}
                                        </div>
                                    }
                                />
                                <RoadmapCard
                                    icon={<Clock className="h-6 w-6 text-purple-600" />}
                                    title="Timeline"
                                    content={
                                        <div className="space-y-4">
                                            {roadmapData.tacticalTimeline.map((phase, i) => (
                                                <div key={i}>
                                                    <h4 className="font-semibold">{phase.phase}</h4>
                                                    <p className="text-sm">Duration: {phase.duration}</p>
                                                    <ul className="list-disc pl-5 text-sm">
                                                        {phase.milestones.map((milestone, j) => (
                                                            <li key={j}>{milestone}</li>
                                                        ))}
                                                    </ul>
                                                </div>
                                            ))}
                                        </div>
                                    }
                                />
                                <RoadmapCard
                                    icon={<Target className="h-6 w-6 text-indigo-600" />}
                                    title="Career Progression"
                                    content={
                                        <div className="space-y-4">
                                            <p><span className="font-semibold">Current Role:</span> {roadmapData.careerProgression.currentRole}</p>
                                            <div>
                                                <h4 className="font-semibold">Future Roles:</h4>
                                                <ul className="list-disc pl-5">
                                                    {roadmapData.careerProgression.futureRoles.map((role, i) => (
                                                        <li key={i}>{role}</li>
                                                    ))}
                                                </ul>
                                            </div>
                                        </div>
                                    }
                                />
                                <RoadmapCard
                                    icon={<Award className="h-6 w-6 text-purple-600" />}
                                    title="Emerging Trends"
                                    content={
                                        <ul className="list-disc pl-5">
                                            {roadmapData.emergingTrends.map((trend, i) => (
                                                <li key={i}>{trend}</li>
                                            ))}
                                        </ul>
                                    }
                                />
                            </motion.div>

                        ) : (
                            <div className="lg:w-2/3 flex items-center justify-center">
                                <p className="text-xl text-gray-500">Generate your roadmap to see personalized insights here.</p>
                            </div>
                        )}
                    </div>
                </motion.div>
            </div>
        </>

    )
}