
import prisma from "@/lib/prisma";
import { resumeDataInclude } from "@/lib/types";
import ClientUpskillRoadmap from './ClientUpskillRoadmap';
import { createClient } from "@/utils/supabase/server";

export default async function UpskillRoadmap() {
    const supabase = await createClient();
    const { data, error } = await supabase.auth.getUser();

    if (!data.user) {
        return null;
    }

    const resumes = await prisma.resume.findMany({
        where: {
            userId: data.user.id,
        },
        orderBy: {
            updatedAt: "desc",
        },
        include: resumeDataInclude,
    });
    return (
        <div className="container mx-auto py-8">
            <h1 className="text-4xl font-bold text-center mb-12 text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600">
                Personalized Career Roadmap
            </h1>

            <ClientUpskillRoadmap initialResumes={resumes} />
        </div>
    );
}




