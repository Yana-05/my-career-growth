
"use server"

import openai from "@/lib/openai"
import { canUseAITools } from "@/lib/permissions"
import { getUserSubscriptionLevel } from "@/lib/subscription"
import { Resume } from "@prisma/client"
import prisma from "@/lib/prisma"
import { AIResponse } from "@/lib/types"
import { createClient } from "@/utils/supabase/server"

interface SkillProficiency {
  skill: string;
  proficiency: number;
}

interface GenerateRoadmapParams {
  resumeId: string;
  skillProficiencies: SkillProficiency[];
}

export async function generateRoadmap(resume: Resume & {
  workExperiences?: {
    position: string | null;
    company: string | null;
    description: string | null;
  }[]
}, skillProficiency: SkillProficiency[]) {
  const supabase = await createClient();
  const { data, error } = await supabase.auth.getUser();

  if (!data.user) {
    throw new Error("Unauthorized")
  }

  const subscriptionLevel = await getUserSubscriptionLevel(data.user.id)

  if (!canUseAITools(subscriptionLevel)) {
    throw new Error("Upgrade your subscription to use this feature")
  }

  const systemMessage = `
    You are an advanced career development AI strategist specializing in personalized professional growth roadmaps. Your mission is to provide a meticulously crafted upskilling strategy in the form of a structured JSON response. This ensures it can be programmatically used in multiple application components.
    
    ### Comprehensive Roadmap Methodology:
    1. **Skill Gap Analysis**
       - Identify current skill strengths and weaknesses
       - Benchmark against industry standards
       - Highlight critical skill deficiencies
    
    2. **Strategic Learning Path Design**
       - Create a prioritized, phased learning approach
       - Align skill development with career progression
       - Balance theoretical knowledge and practical application
    
    3. **Learning Intervention Recommendations**
       - Curate targeted courses and certifications (include specific titles and links from platforms like Coursera, Udemy, etc.)
       - Must Include at least 5 courses
       - Suggest industry-recognized learning resources
       - Provide multiple learning modality options
    
    4. **Tactical Timeline Mapping**
       - Develop a detailed step-by-step skill acquisition plan
       - Assign timeframes (e.g., weeks/months) to each learning phase
       - Define clear, measurable milestones
       - Must Include at least 3 phases
    
    5. **Emerging Trends Awareness**
       - Highlight innovative and emerging technologies relevant to the user's field
       - Suggest areas to explore for future-proofing their career
    
    6. **Career Progression Pathways**
       - Outline potential roles the user can target with their upgraded skills
       - Provide actionable steps to transition into these roles
       - Recommend networking and industry engagement strategies
    
    7. **Structured Learning Path**
       - Break down concepts and technologies to master, in a logical progression
       - Integrate theoretical foundations with practical project suggestions
    
    ---
    
    ### JSON Response Format:
    Your response **must** be formatted as JSON and adhere to this structure:
    \`\`\`json
    {
      "skillGapAnalysis": {
        "strengths": ["list of strengths"],
        "weaknesses": ["list of weaknesses"],
        "criticalDeficiencies": ["list of deficiencies"],
        "industryStandardProficiencies": [
          {
            "skill": "Skill Name",
            "requiredProficiency": 85  // 0-100 scale
          }
        ]
      },
      "strategicLearningPath": {
        "phases": [
          {
            "phaseTitle": "Phase 1 Title",
            "description": "Overview of phase objectives",
            "conceptsToMaster": ["list of concepts"],
            "technologiesToLearn": ["list of technologies"]
          }
          // Additional phases...
        ]
      },
      "learningInterventions": [
        {
          "courseTitle": "Course Title",
          "platform": "Platform Name",
          "link": "Course URL",
          "description": "Brief description of the course"
        }
        // Additional courses...
      ],
      "tacticalTimeline": [
        {
          "phase": "Phase Title",
          "duration": "e.g., 4 weeks",
          "milestones": ["list of milestones"]
        }
        // Additional timeline entries...
      ],
      "emergingTrends": ["list of trends"],
      "careerProgression": {
        "currentRole": "User's current role",
        "futureRoles": ["list of potential roles"],
        "transitionSteps": ["list of actionable steps"]
      }
    }
    \`\`\`
    
    Consider the user's current proficiency levels when analyzing skill gaps and creating the roadmap. For the industryStandardProficiencies, identify and include the 6 most critical skills required for the recommended future roles, with their expected proficiency levels on a 0-100 scale.
    
    Your response must strictly adhere to this JSON format. Avoid any plain text outside the JSON object at all not even a blank space other than this JSON.
    
    ---
    
    ### Guiding Principles:
    - Hyper-personalized approach
    - Data-driven recommendations
    - Future-oriented skill positioning
    - Holistic professional development
    `;

  const userMessage = `
    Professional Profile for Upskilling Roadmap:
    
    ### Current Professional Identity:
    - Job Title: ${resume.jobTitle || "N/A"}
    
    ### Professional Experience Trajectory:
    ${resume.workExperiences
      ?.map(
        (exp) => `
    - **Position**: ${exp.position || "N/A"}
      - **Company**: ${exp.company || "N/A"}
      - **Key Responsibilities**: ${exp.description || "N/A"}
    `
      )
      .join("\n")}
    
    ### Skill Inventory and Current Proficiencies:
    ${resume.skills?.join(", ") || "N/A"}
    
    Current Proficiency Levels:
    ${skillProficiency.map(prof =>
        `- ${prof.skill}: ${prof.proficiency}/100`
      ).join("\n")}
    
    ### Strategic Development Objectives:
    - Identify skill enhancement opportunities
    - Create a targeted professional growth roadmap
    - Recommend high-impact learning interventions
    - Provide structured timeline for skill acquisition
    - Suggest relevant courses with links
    - Highlight emerging trends and career advancement paths
    
    ### Context for Personalization:
    - Leverage existing professional foundation
    - Align skill development with career aspirations
    - Focus on innovative and emerging competencies
    `;


  const completion = await openai.chat.completions.create({
    model: "gpt-4",
    messages: [
      {
        role: "system",
        content: systemMessage,
      },
      {
        role: "user",
        content: userMessage,
      },
    ],
      temperature: 0.7,
  })


  const aiResponse = JSON.parse(completion.choices[0].message.content || "") as AIResponse;

  if (!aiResponse) {
    throw new Error("Failed to generate AI response")
  }
  console.log(aiResponse.skillGapAnalysis.strengths)

  // Store the roadmap in the database
  const roadmap = await prisma.upskillRoadmap.create({
    data: {
      userId: data.user.id,
      resumeId: resume.id,
      strengths: { set: aiResponse.skillGapAnalysis.strengths },
      weaknesses: { set: aiResponse.skillGapAnalysis.weaknesses },
      criticalDeficiencies: { set: aiResponse.skillGapAnalysis.criticalDeficiencies },
      currentRole: aiResponse.careerProgression.currentRole,
      futureRoles: { set: aiResponse.careerProgression.futureRoles },
      transitionSteps: { set: aiResponse.careerProgression.transitionSteps },
      emergingTrends: { set: aiResponse.emergingTrends },
      industryStandardProficiencies: {
        create: aiResponse.skillGapAnalysis.industryStandardProficiencies.map(prof => ({
          skill: prof.skill,
          requiredProficiency: prof.requiredProficiency,
        })),
      },
      strategicLearningPath: {
        create: aiResponse.strategicLearningPath.phases.map(phase => ({
          phaseTitle: phase.phaseTitle,
          description: phase.description,
          conceptsToMaster: phase.conceptsToMaster,
          technologiesToLearn: phase.technologiesToLearn,
        })),
      },
      learningInterventions: {
        create: aiResponse.learningInterventions.map(intervention => ({
          courseTitle: intervention.courseTitle,
          platform: intervention.platform,
          link: intervention.link,
          description: intervention.description,
        })),
      },
      tacticalTimeline: {
        create: aiResponse.tacticalTimeline.map(timeline => ({
          phase: timeline.phase,
          duration: timeline.duration,
          milestones: timeline.milestones,
        })),
      },
    },
    include: {
      industryStandardProficiencies: true,
      strategicLearningPath: true,
      learningInterventions: true,
      tacticalTimeline: true,
    }
  })

  return roadmap
}

export async function getLatestRoadmap(resumeId: string) {
  const supabase = await createClient();
  const { data, error } = await supabase.auth.getUser();

  if (!data.user) {
    throw new Error("Unauthorized")
  }

  const roadmap = await prisma.upskillRoadmap.findFirst({
    where: {
      userId: data.user.id,
      resumeId,
    },
    orderBy: {
      createdAt: 'desc',
    },
    include: {
      industryStandardProficiencies: true,
      learningInterventions: true,
      strategicLearningPath: true,
      tacticalTimeline: true,
    },
  })

  return roadmap
}