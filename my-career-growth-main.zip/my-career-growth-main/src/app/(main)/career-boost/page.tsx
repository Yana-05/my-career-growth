"use client"
import { Button } from "@/components/ui/button"
import { Briefcase, TrendingUp, Zap, ChevronRight, FileUser } from 'lucide-react'
import Link from "next/link"
import { motion } from "framer-motion"

export default function CareerBoostFeatures() {
    return (
        <div className="min-h-screen bg-gradient-to-br from-gray-50 via-gray-100 to-white text-gray-800">

            <main className="py-12 px-4 md:px-6 lg:px-8 mb-24">
                <div className="container mx-auto">
                    <motion.h2
                        className="text-3xl md:text-4xl font-bold mb-12 text-center text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600"
                        initial={{ opacity: 0, y: -20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.5 }}
                    >
                        Boost Your Career with AI-Powered Tools
                    </motion.h2>
                    <nav className="hidden md:flex space-x-6 w-full mx-auto py-4">
                        <a href="#job-matching" className="text-gray-600 hover:text-indigo-600 transition-colors">Job Matching &#62;&#62;</a>
                        <a href="#skill-analysis" className="text-gray-600 hover:text-indigo-600 transition-colors">Skill Analysis &#62;&#62;</a>
                        <a href="#ai-cover-letter" className="text-gray-600 hover:text-indigo-600 transition-colors">AI Cover Letter &#62;&#62;</a>
                    </nav>

                    <div className="space-y-32">
                        <FeatureSection
                            id="job-matching"
                            title="Smart Job Matching"
                            description="Find the perfect job opportunities that match your unique skills and experience. Simply upload your resume or enter your LinkedIn profile URL, and we'll fetch a list of recent jobs posted on LinkedIn that align with your skillset."
                            icon={<Briefcase className="h-16 w-16 text-indigo-600" />}
                            buttonText="Start Job Matching"
                            buttonLink="/find-jobs"
                            imageUrl="/job-matching.png"
                        />

                        <FeatureSection
                            id="skill-analysis"
                            title="Skill Analysis & Roadmap"
                            description="Get a complete analysis of your current skill set and receive a personalized roadmap designed to help you upskill. We'll recommend technologies to learn, concepts to master, and provide direct links to relevant courses to get you started. All based on your resume or LinkedIn profile."
                            icon={<TrendingUp className="h-16 w-16 text-purple-600" />}
                            buttonText="Analyze Your Skills"
                            buttonLink="/upskill-roadmap"
                            imageUrl="/roadmap.jpg"
                            reverse
                        />

                        <FeatureSection
                            id="ai-cover-letter"
                            title="AI Cover Letter generation"
                            description="Generate customised cover letter for each individual jobs relevant to their requirements with one click, saving you time and increasing your chances of landing your dream job."
                            icon={<FileUser className="h-10 w-10 text-purple-600" />}
                            buttonText="Generate Cover Letter"
                            buttonLink="/auto-apply"
                            imageUrl="coverletter.jpg"
                        />
                    </div>
                </div>
            </main>

            <footer className="py-8 px-4 md:px-6 lg:px-8 bg-white border-t border-gray-200">
                <div className="container mx-auto flex flex-col md:flex-row justify-between items-center">
                    <p className="text-gray-600 mb-4 md:mb-0">&copy; 2023 Career Boost AI. All rights reserved.</p>
                    <nav className="flex space-x-6">
                        <a href="#" className="text-gray-600 hover:text-indigo-600 transition-colors">Privacy Policy</a>
                        <a href="#" className="text-gray-600 hover:text-indigo-600 transition-colors">Terms of Service</a>
                        <a href="#" className="text-gray-600 hover:text-indigo-600 transition-colors">Contact Us</a>
                    </nav>
                </div>
            </footer>
        </div>
    )
}

function FeatureSection({ id, title, description, icon, buttonText, buttonLink, imageUrl, reverse = false }: {
    id: string;
    title: string;
    description: string;
    icon: React.ReactNode;
    buttonText: string;
    buttonLink: string;
    imageUrl: string;
    reverse?: boolean;
}) {
    return (
        <motion.section
            id={id}
            className={`flex flex-col ${reverse ? 'md:flex-row-reverse' : 'md:flex-row'} items-center gap-8 md:gap-16`}
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
        >
            <div className="w-full md:w-1/2 space-y-4">
                <div className="flex items-center space-x-4 mb-4">
                    {icon}
                    <h3 className="text-2xl md:text-3xl font-bold text-gray-900">{title}</h3>
                </div>
                <p className="text-gray-700 text-lg leading-relaxed mb-6">{description}</p>
                <Link
                    href={buttonLink}
                    className="flex items-center justify-center w-full md:max-w-[300px] px-8 py-3 text-lg font-medium bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white rounded-md"
                >
                    {buttonText} <ChevronRight className="ml-2 h-5 w-5" />
                </Link>
            </div>
            <motion.div
                className="w-full md:w-1/2"
                whileHover={{ scale: 1.02 }}
                transition={{ type: "spring", stiffness: 300 }}
            >
                <img src={imageUrl} alt={title} className="w-full h-auto rounded-lg shadow-lg" />
            </motion.div>
        </motion.section>
    )
}

