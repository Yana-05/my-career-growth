import PremiumModal from "@/components/premium/PremiumModal";
import { getUserSubscriptionLevel } from "@/lib/subscription";
import Navbar from "./Navbar";
import SubscriptionLevelProvider from "./SubscriptionLevelProvider";
import Footer from "@/components/Footer";
import { createClient } from "@/utils/supabase/server";

export default async function Layout({
  children,
}: {
  children: React.ReactNode;
}) {
  const supabase = await createClient();
  const { data, error } = await supabase.auth.getUser()

  if (!data.user) {
    return null;
  }

  const userSubscriptionLevel = await getUserSubscriptionLevel(data.user.id);

  return (
    <SubscriptionLevelProvider userSubscriptionLevel={userSubscriptionLevel}>
      <div className="flex min-h-[80vh] flex-col ">
        {children}
        <PremiumModal />
      </div>
      <Footer />
    </SubscriptionLevelProvider>
  );
}
