import { canCreateResume } from "@/lib/permissions";
import prisma from "@/lib/prisma";
import { getUserSubscriptionLevel } from "@/lib/subscription";
import { resumeDataInclude } from "@/lib/types";
import { Metadata } from "next";
import CreateResumeButton from "./CreateResumeButton";
import ResumeItem from "./ResumeItem";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { ArrowUpRight, ChevronRight } from "lucide-react";
import UploadResumeButton from "./UploadResumeButton";
import { redirect } from 'next/navigation'

import { createClient } from '@/utils/supabase/server'

export const metadata: Metadata = {
  title: "Your resumes",
};

export default async function Page() {
  const supabase = await createClient();
  const { data, error } = await supabase.auth.getUser()

  if (!data.user) {
    redirect("/login")
  }

  const [resumes, totalCount, subscriptionLevel] = await Promise.all([
    prisma.resume.findMany({
      where: {
        userId: data.user.id,
      },
      orderBy: {
        updatedAt: "desc",
      },
      include: resumeDataInclude,
    }),
    prisma.resume.count({
      where: {
        userId: data.user.id,
      },
    }),
    getUserSubscriptionLevel(data.user.id),
  ]);
  console.log(resumes.map((resume) => resume.workExperiences.map((exp) => exp.position)))
  return (
    <main className="mx-auto w-full md:max-w-[75%] space-y-6 px-3 py-6 ">
      <div className="flex space-x-2 items-start">
        <CreateResumeButton
          canCreate={canCreateResume(subscriptionLevel, totalCount)}
        />
        <UploadResumeButton canCreate={canCreateResume(subscriptionLevel, totalCount)} />

      </div>
      <div className="space-y-1">
        <h1 className="text-3xl font-bold gradient-text">Your resumes</h1>
        <p>Total: {totalCount}</p>
      </div>
      <div className="flex w-full grid-cols-2 flex-col gap-3 sm:grid md:grid-cols-3 lg:grid-cols-4">
        {resumes.map((resume) => (
          <ResumeItem key={resume.id} resume={resume} />
        ))}
      </div>
    </main >
  );
}
