"use server";

import prisma from "@/lib/prisma";
import { createClient } from "@/utils/supabase/server";
import { del } from "@vercel/blob";
import { revalidatePath } from "next/cache";

export async function deleteResume(id: string) {
  const supabase = await createClient();
  const { data, error } = await supabase.auth.getUser();
  if (!data.user) throw new Error("Unauthorized")


  const resume = await prisma.resume.findUnique({
    where: {
      id,
      userId: data.user.id,
    },
  });

  if (!resume) {
    throw new Error("Resume not found");
  }

  if (resume.photoUrl) {
    await del(resume.photoUrl);
  }

  await prisma.resume.delete({
    where: {
      id,
    },
  });

  revalidatePath("/resumes");
}


