"use client";

import { Button } from "@/components/ui/button";
import usePremiumModal from "@/hooks/usePremiumModal";
import { Loader2, Upload } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState } from "react";
// import { toast } from "@/components/ui/use-toast";

interface UploadResumeButtonProps {
    canCreate: boolean;
}

export default function UploadResumeButton({ canCreate }: UploadResumeButtonProps) {
    const premiumModal = usePremiumModal();
    const router = useRouter();
    const [isLoading, setIsLoading] = useState(false);

    const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (!file) return;

        try {
            setIsLoading(true);
            const formData = new FormData();
            formData.append('file', file);

            const response = await fetch('/api/parse-pdf', {
                method: 'POST',
                body: formData,
            });

            if (!response.ok) {
                throw new Error('Failed to process PDF');
            }

            const { resumeData } = await response.json();

            // Store the parsed resume data in localStorage
            localStorage.setItem('uploadedResumeData', JSON.stringify(resumeData));

            // Navigate to editor
            router.push('/editor?step=general-info&source=upload');

        } catch (error) {
            console.error('Error processing PDF:', error);
            // toast({
            //     title: "Error",
            //     description: "Failed to process your resume. Please try again.",
            //     variant: "destructive",
            // });
        } finally {
            setIsLoading(false);
        }
    }

    if (canCreate) {
        return (
            <>
                <input
                    type="file"
                    accept=".pdf"
                    onChange={handleFileUpload}
                    style={{ display: 'none' }}
                    id="resume-upload"
                />
                <Button
                    asChild
                    className="flex w-fit gap-2 border-2 h-12 bg-white text-black hover:bg-purple-50 border-purple-500"
                    onClick={() => document.getElementById('resume-upload')?.click()}
                    disabled={isLoading}
                >
                    <div className="text-lg text-purple-600 cursor-pointer">
                        {isLoading ? <Loader2 className="size-8 animate-spin" /> : <Upload className="size-8" />}
                        {isLoading ? 'Processing...' : 'Upload resume'}
                    </div>
                </Button>
            </>
        );
    }

    return null;
}
