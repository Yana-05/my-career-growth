'use client'

import { useState } from 'react';
import { JobInterface } from '@/lib/types';
import { Resume } from '@prisma/client';
import TagsInput from 'react-tagsinput'// Import the default styles
import { JobCard } from './JobCard';
import ResumeItem from '../resumes/ResumeItem';
import SearchLocation from '@/components/SearchLocation';
import { ArrowUpRight, Link, WandSparklesIcon } from 'lucide-react';
import { CoverLetterButton } from '@/components/CoverLetter';
import { AdaptResumeButton } from '@/components/AdaptResumeButton';


interface ClientFindJobsProps {
    initialResumes: Resume[];
}

export default function ClientFindJobs({ initialResumes }: ClientFindJobsProps, jobs: JobInterface[]) {
    const [selectedResume, setSelectedResume] = useState<Resume | null>(null);
    const [jobsList, setJobsList] = useState<JobInterface[]>([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [selectedJob, setSelectedJob] = useState<JobInterface | null>(null);

    // Tag states
    const [roleTags, setRoleTags] = useState<string[]>([]);
    const [skillTags, setSkillTags] = useState<string[]>([]);
    // const [locationTags, setLocationTags] = useState<string[]>([]);
    const [locationValue, setLocationValue] = useState<string>("");
    const handleResumeSelect = (resume: Resume) => {
        //@ts-ignore
        const roles = resume.workExperiences?.map((exp: any) => exp.position) || [];
        setRoleTags(roles);

        // Extract skills
        const skills = resume.skills?.map((skill) => skill) || [];
        setSkillTags(skills);

        // Set location
        const location = resume.country;
        setLocationValue(location ? location : "");

        // Set selected resume after extracting data
        setSelectedResume(resume);
    };

    const handleJobsLoaded = (jobs: JobInterface[]) => {
        setJobsList(jobs);
        if (jobs.length > 0) {
            setSelectedJob(jobs[0]);
        }
    };

    const handleSearch = async () => {
        setLoading(true);
        setError(null);
        try {
            const queryParams = new URLSearchParams({
                roles: roleTags.join(' OR '),
                location: locationValue
            });
            const response = await fetch(`/api/jobs?${queryParams}`);
            const data = await response.json();
            handleJobsLoaded(data || []);
        } catch (err) {
            setError('Failed to fetch jobs. Please try again.');
            console.error('Error fetching jobs:', err);
        } finally {
            setLoading(false);
        }
    };


    return (
        <div className="space-y-8">
            {/* Resume Selection */}
            <h2>Select Your Resume :</h2>
            <div className=" grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">

                {initialResumes.map((resume) => (
                    <button
                        key={resume.id}
                        onClick={() => handleResumeSelect(resume)}
                        className={`p-4 border rounded-lg text-left transition-colors ${selectedResume?.id === resume.id
                            ? 'border-[#afa1fb] bg-[#f4f2ff]'
                            : 'hover:bg-gray-50'
                            }`}
                    >
                        <h3 className="font-medium">{resume.title}</h3>
                        <p className="text-sm text-gray-600">
                            {new Date(resume.updatedAt).toISOString().split('T')[0]}
                        </p>
                        {/* <ResumeItem key={resume.id} resume={resume} /> */}
                    </button>
                ))}
            </div>

            {/* Tag Inputs */}
            {selectedResume && (
                <div className="space-y-4 mb-12">
                    <div className='min-w-full flex flex-col space-y-2 md:flex-row md:space-y-0 md:space-x-4'>
                        <div className='flex-1'>
                            <label className="block text-sm font-medium mb-2">Roles</label>
                            <TagsInput
                                value={roleTags}
                                onChange={setRoleTags}
                                inputProps={{
                                    placeholder: 'Add roles...',
                                    className: 'react-tagsinput-input'
                                }}
                                className="react-tagsinput w-full rounded-md"
                            />
                        </div>
                        <div className='flex-1'>
                            {/* <label className="block text-sm font-medium mb-2">Locations</label> */}
                            {/* <TagsInput
                                value={locationValue}
                                onChange={setLocationTags}
                                inputProps={{
                                    placeholder: 'Add locations...',
                                    className: 'react-tagsinput-input'
                                }}
                                className="react-tagsinput  w-full rounded-md"
                            /> */}
                            <SearchLocation
                                value={locationValue}
                                onChange={setLocationValue} />
                        </div>
                    </div>
                    <div>
                        <label className="block text-sm font-medium mb-2">Skills</label>
                        <TagsInput
                            value={skillTags}
                            onChange={setSkillTags}
                            inputProps={{
                                placeholder: 'Add skills...',
                                className: 'react-tagsinput-input'
                            }}
                            className="react-tagsinput  w-full rounded-md"
                        />

                    </div>


                    <button
                        onClick={handleSearch}
                        disabled={loading}
                        className="w-fit text-white py-2 px-4 rounded-lg gradient-primary hover:bg-zinc-600 disabled:bg-zinc-300"
                    >
                        {loading ? 'Searching...' : 'Find Jobs'}
                    </button>
                </div>
            )}

            {/* Error Message */}
            {error && (
                <div className="text-red-500 text-center">
                    {error}
                </div>
            )}

            {/* Jobs Section */}
            {jobsList.length > 0 && (
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 px-2">
                    {/* Jobs List - Left Side */}
                    <div className="lg:col-span-1 space-y-4 overflow-y-auto max-h-[100vh] px-4 
                       scrollbar-thin scrollbar-thumb-zinc-500 scrollbar-track-transparent scrollbar-thumb-rounded-full hover:scrollbar-thumb-zinc-500">
                        {jobsList.map((job, index) => (
                            <button
                                key={`${job.title}-${index}`}
                                onClick={() => setSelectedJob(job)}
                                className={`w-full text-left ${selectedJob?.title === job.title ? 'ring-2 ring-indigo-500 ring-rounded-lg' : ''
                                    }`}
                            >
                                <JobCard job={job} />
                            </button>
                        ))}
                    </div>

                    {/* Job Details - Right Side */}
                    <div className="lg:col-span-2 bg-white rounded-lg p-6 shadow-sm max-h-[100vh] overflow-y-auto
                        scrollbar-thin scrollbar-thumb-zinc-500 scrollbar-track-transparent  hover:scrollbar-thumb-zinc-500">
                        {selectedJob ? (
                            <div className="space-y-6">
                                <h2 className="text-2xl font-bold">{selectedJob.title}</h2>
                                <div className="space-y-2">
                                    <p className="text-lg">{selectedJob.company_name}</p>
                                    <p className="text-gray-600">{selectedJob.location}</p>
                                    <p className="text-gray-600">{selectedJob.detected_extensions.schedule_type}</p>
                                </div>
                                <div className="flex flex-col sm:flex-row gap-4 pt-6">


                                    {/* @ts-ignore */}
                                    <CoverLetterButton selectedJob={selectedJob} selectedResume={selectedResume} />
                                    {/* @ts-ignore */}
                                    <AdaptResumeButton selectedJob={selectedJob} selectedResume={selectedResume} />
                                    <a
                                        href={selectedJob.apply_options[0].link}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="flex-1 px-6 py-3 bg-white border-2 border-purple-500 text-purple-500 rounded-lg hover:bg-purple-100/40 text-center flex items-center justify-center"
                                    >
                                        Apply on {selectedJob.apply_options[0].title} <ArrowUpRight className="w-4 h-4 ml-1" />
                                    </a>
                                </div>
                                <div className="prose max-w-none">
                                    <h3 className="text-xl font-semibold">Job Description</h3>
                                    <div
                                        dangerouslySetInnerHTML={{ __html: selectedJob.description }}
                                        className="text-gray-700 text-sm [&_ul]:list-disc [&_ul]:ml-4 [&_li]:my-2 [&_p]:my-2 whitespace-pre-line"
                                    />
                                </div>

                                {/* Action Buttons */}

                            </div>
                        ) : (
                            <div className="text-center text-gray-500">
                                Select a job to view details
                            </div>
                        )}
                    </div>
                </div>
            )}

            {jobsList.length === 0 && !loading && !error && (
                <div className="text-center text-gray-500">
                    Select a resume and search criteria to find jobs
                </div>
            )}
        </div>
    );
}




