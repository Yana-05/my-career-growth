import { Button } from "@/components/ui/button"
import FeatureCard from "@/components/FeatureCard"
import { FileText, Briefcase, TrendingUp, Zap, ChevronRight, CreditCard, FileUser } from 'lucide-react'
import Link from "next/link"
import LoginLogoutButton from "@/components/LoginLogoutButton";

export default async function LandingPage() {

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-gray-100 to-white text-gray-800">

      <main>
        <section className="relative py-20 px-4 md:px-6 lg:px-8 text-center overflow-hidden md:h-[50vh] space-y-12">
          <div className="absolute inset-0 bg-gradient-to-br from-indigo-50 via-purple-50 to-white opacity-60"></div>
          <div className="container mx-auto max-w-3xl relative z-10">
            <h2 className="pb-2 text-4xl md:text-5xl font-bold mb-6 text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600">
              Supercharge Your Career with AI
            </h2>
            <p className="text-[14px] md:text-xl mb-8 text-gray-700">
              Career Boost AI revolutionizes your job search with AI-powered tools for resume creation, job matching, skill analysis, and automated applications.
            </p>
            <div className="md:space-x-4 space-y-4">
              <Link
                href="/career-boost"
                className="inline-block text-lg px-8 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white rounded-md"
              >

                <span className="flex items-center">
                  Start Your Career Boost <ChevronRight className="ml-2 h-5 w-5" />
                </span>
              </Link>

              <Link
                href="/resumes"
                className="inline-block text-lg px-8 py-3 border border-indigo-200 text-indigo-600 hover:bg-indigo-50 rounded-md"
              >
                <span className="flex items-center">
                  AI Resume Builder <ChevronRight className="ml-2 h-5 w-5" />
                </span>
              </Link>
            </div>
          </div>
        </section>

        <section id="features" className="py-20 px-4 md:px-6 lg:px-8 bg-white">
          <div className="container mx-auto">
            <h3 className="text-3xl font-bold mb-12 text-center text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600">
              Powerful Features
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              <Link href="/resumes" className="transform transition-transform hover:scale-105">
                <FeatureCard
                  icon={<FileText className="h-10 w-10 text-indigo-600" />}
                  title="AI Resume Generator"
                  description="Create professional, tailored resumes with the help of advanced AI technology."
                />
              </Link>
              <div className="transform transition-transform hover:scale-105">
                <FeatureCard
                  icon={<Briefcase className="h-10 w-10 text-purple-600" />}
                  title="Smart Job Matching"
                  description="Find the perfect job opportunities that match your unique skills and experience."
                />
              </div>
              <div className="transform transition-transform hover:scale-105">
                <FeatureCard
                  icon={<TrendingUp className="h-10 w-10 text-indigo-600" />}
                  title="Skill Analysis & Roadmap"
                  description="Get insights into your current skills and a personalized roadmap for upskilling."
                />
              </div>
              <div className="transform transition-transform hover:scale-105">
                <FeatureCard
                  icon={<FileUser className="h-10 w-10 text-purple-600" />}
                  title="Customised Cover Letter"
                  description="Automatically generate a customized cover letter relevant to specific job requirements."
                />
              </div>
            </div>
          </div>
        </section>

        <section className="py-20 px-4 md:px-6 lg:px-8 bg-gradient-to-br from-gray-50 via-indigo-50 to-purple-50">
          <div className="container mx-auto text-center">
            <h3 className="text-3xl font-bold mb-6 text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600">
              Ready to Boost Your Career?
            </h3>
            <p className="text-xl mb-8 text-gray-700">
              Join thousands of professionals who have accelerated their careers with Career Boost AI.
            </p>
            <Button size="lg" className="text-lg px-8 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white">
              Get Started Now <ChevronRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </section>
      </main>

      <footer className="py-8 px-4 md:px-6 lg:px-8 bg-white border-t border-gray-200">
        <div className="container mx-auto flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-600 mb-4 md:mb-0">&copy; 2023 Career Boost AI. All rights reserved.</p>
          <nav className="flex space-x-6">
            <a href="#" className="text-gray-600 hover:text-indigo-600 transition-colors">Privacy Policy</a>
            <a href="#" className="text-gray-600 hover:text-indigo-600 transition-colors">Terms of Service</a>
            <a href="#" className="text-gray-600 hover:text-indigo-600 transition-colors">Contact Us</a>
          </nav>
        </div>
      </footer>
    </div>
  )
}



